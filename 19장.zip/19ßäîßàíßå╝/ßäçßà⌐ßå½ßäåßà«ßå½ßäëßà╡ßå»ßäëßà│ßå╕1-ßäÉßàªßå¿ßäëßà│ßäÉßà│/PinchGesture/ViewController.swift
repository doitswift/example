//
//  ViewController.swift
//  PinchGesture
//
//  Created by Ho-Jeong Song on 2015. 12. 13..
//  Copyright © 2015년 Ho-Jeong Song. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtPinch: UILabel!

    var initialFontSize:CGFloat!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(ViewController.doPinch(_:)))
        self.view.addGestureRecognizer(pinch)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func doPinch(pinch: UIPinchGestureRecognizer) {
        if (pinch.state == UIGestureRecognizerState.Began) {
            initialFontSize = txtPinch.font.pointSize
        } else {
            txtPinch.font = txtPinch.font.fontWithSize(initialFontSize * pinch.scale)
        }
    }
}

