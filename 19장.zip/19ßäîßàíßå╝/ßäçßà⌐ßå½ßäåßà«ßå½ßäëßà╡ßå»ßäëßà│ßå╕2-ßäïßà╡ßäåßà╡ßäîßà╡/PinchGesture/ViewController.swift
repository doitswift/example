//
//  ViewController.swift
//  PinchGesture
//
//  Created by Ho-Jeong Song on 2015. 12. 13..
//  Copyright © 2015년 Ho-Jeong Song. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imgPinch: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(ViewController.doPinch(_:)))
        self.view.addGestureRecognizer(pinch)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func doPinch(pinch: UIPinchGestureRecognizer) {
        imgPinch.transform = CGAffineTransformScale(imgPinch.transform, pinch.scale, pinch.scale)
        pinch.scale = 1
    }
}
