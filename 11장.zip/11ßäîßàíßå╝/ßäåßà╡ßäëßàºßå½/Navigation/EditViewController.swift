//
//  EditViewController.swift
//  Navigation
//
//  Created by LeeBeomGeun on 2015. 10. 25..
//  Copyright © 2015년 LeeBeomGeun. All rights reserved.
//

import UIKit


protocol EditDelegate {
    func didMessageEditDone(controller: EditViewController, message: String)
    func didImageOnOffDone(controller: EditViewController, isOn: BooleanType)
    func didImageZoomDone(controller: EditViewController, isZoom: BooleanType)
}


class EditViewController: UIViewController {
    
    var textWayValue: String = ""
    var textMessage: String = ""
    var isOn = false
    var isZoom = false
    var delegate : EditDelegate?

    @IBOutlet weak var txMessage: UITextField!
    @IBOutlet weak var lblWay: UILabel!
    @IBOutlet weak var swIsOn: UISwitch!
    @IBOutlet weak var btnResize: UIButton!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        lblWay.text = textWayValue
        txMessage.text = textMessage
        swIsOn.on = isOn
        if isZoom {
            btnResize.setTitle("확대", forState: .Normal)
        } else {
            btnResize.setTitle("축소", forState: .Normal)
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func swImageOnOff(sender: UISwitch) {
        if sender.on {
            isOn = true
        } else {
            isOn = false
        }
    }
    
    @IBAction func swImageZoom(sender: UISwitch) {
        if sender.on {
            isZoom = true
        } else {
            isZoom = false
        }
    }

    
    @IBAction func btnResizeImage(sender: UIButton) {
        if isZoom {
            isZoom = false
            btnResize.setTitle("축소", forState: .Normal)
        } else {
            isZoom = true
            btnResize.setTitle("확대", forState: .Normal)
        }
    }
    
    
    @IBAction func btnBarDone(sender: UIBarButtonItem) {
        if delegate != nil {
            delegate?.didMessageEditDone(self, message: txMessage.text!)
            delegate?.didImageOnOffDone(self, isOn: isOn)
            delegate?.didImageZoomDone(self, isZoom: isZoom)
        }
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    
    @IBAction func btnDone(sender: UIButton) {
        
        if delegate != nil {
            delegate?.didMessageEditDone(self, message: txMessage.text!)
            delegate?.didImageOnOffDone(self, isOn: isOn)
            delegate?.didImageZoomDone(self, isZoom: isZoom)
        }
        
        self.navigationController?.popViewControllerAnimated(true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
