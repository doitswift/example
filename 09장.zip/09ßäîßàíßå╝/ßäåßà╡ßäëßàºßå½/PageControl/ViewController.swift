//
//  ViewController.swift
//  PageControl
//
//  Created by Ho-Jeong Song on 2018. 10. 2..
//  Copyright © 2018년 Ho-Jeong Song. All rights reserved.
//

import UIKit

let NUM_PAGE = 10

class ViewController: UIViewController {
    @IBOutlet var lblPageNumber: UILabel!
    @IBOutlet var pageControl: UIPageControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        pageControl.numberOfPages = NUM_PAGE
        pageControl.currentPage = 0
        
        pageControl.pageIndicatorTintColor = UIColor.green
        pageControl.currentPageIndicatorTintColor = UIColor.red
        
        lblPageNumber.text = String(pageControl.currentPage+1)
    }

    @IBAction func PageChange(_ sender: UIPageControl) {
        lblPageNumber.text = String(pageControl.currentPage+1)
    }
    
}

