//
//  ViewController.swift
//  Table
//
//  Created by bglee on 2022/11/08.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

