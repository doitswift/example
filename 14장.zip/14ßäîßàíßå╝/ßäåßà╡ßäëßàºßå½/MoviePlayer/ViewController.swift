//
//  ViewController.swift
//  MoviePlayer
//
//  Created by Ho-Jeong Song on 2016. 1. 7..
//  Copyright © 2016년 Ho-Jeong Song. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnPlayInternalMovie(sender: AnyObject) {
        // 내부 파일 mp4
        let filePath:String? = NSBundle.mainBundle().pathForResource("FastTyping", ofType: "mp4")
        let url = NSURL(fileURLWithPath: filePath!)

        playVideo(url)
    }
    
    @IBAction func btnPlayInternalMovie2(sender: UIButton) {
        // 내부 파일 mov
        let filePath:String? = NSBundle.mainBundle().pathForResource("Mountaineering", ofType: "mov")
        let url = NSURL(fileURLWithPath: filePath!)
        
        playVideo(url)
    }
    
    @IBAction func btnPlayExternalMovie(sender: UIButton) {
        // 외부 파일 mp4
        let url = NSURL(string: "https://dl.dropboxusercontent.com/s/e38auz050w2mvud/Fireworks.mp4")!
        
        playVideo(url)
    }
    
    @IBAction func btnPlayExternalMovie2(sender: UIButton) {
        // 외부 파일 mov
        let url = NSURL(string: "https://dl.dropboxusercontent.com/s/ijybpprsmx0bgre/Seascape.mov")!
        
        playVideo(url)
    }
    
    
    private func playVideo(url: NSURL)  {
        let playerController = AVPlayerViewController()
        
        let player = AVPlayer(URL: url)
        playerController.player = player
        
        self.presentViewController(playerController, animated: true) {
            player.play()
        }
    }
}
