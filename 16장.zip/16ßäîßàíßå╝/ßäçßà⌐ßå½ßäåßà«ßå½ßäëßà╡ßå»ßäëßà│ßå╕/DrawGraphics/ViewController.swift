//
//  ViewController.swift
//  DrawGraphics
//
//  Created by Ho-Jeong Song on 2015. 10. 6..
//  Copyright © 2015년 Ho-Jeong Song. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imgView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnDrawLine(sender: UIButton) {
        UIGraphicsBeginImageContext(imgView.frame.size)
        let context = UIGraphicsGetCurrentContext()
        
        // Draw Line
        CGContextSetLineWidth(context, 2.0)
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        
        CGContextMoveToPoint(context, 50, 50)
        CGContextAddLineToPoint(context, 250, 250)
        CGContextStrokePath(context)

        // Draw Triangle
        CGContextSetLineWidth(context, 4.0)
        CGContextSetStrokeColorWithColor(context, UIColor.blueColor().CGColor)
        
        CGContextMoveToPoint(context, 150, 200)
        CGContextAddLineToPoint(context, 250, 350)
        CGContextAddLineToPoint(context, 50, 350)
        CGContextAddLineToPoint(context, 150, 200)
        CGContextStrokePath(context)
        
        imgView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }

    @IBAction func btnDrawRectangle(sender: UIButton) {
        UIGraphicsBeginImageContext(imgView.frame.size)
        let context = UIGraphicsGetCurrentContext()
        
        // Draw Rectangle
        CGContextSetLineWidth(context, 2.0)
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        
        CGContextAddRect(context, CGRect(x: 50, y: 100, width: 200, height: 200))
        CGContextStrokePath(context)
        
        imgView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    @IBAction func btnDrawCircle(sender: UIButton) {
        UIGraphicsBeginImageContext(imgView.frame.size)
        let context = UIGraphicsGetCurrentContext()
        
        // Draw Ellipse
        CGContextSetLineWidth(context, 2.0)
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        
        CGContextAddEllipseInRect(context, CGRect(x: 50, y: 50, width: 200, height: 100))
        CGContextStrokePath(context)

        // Draw Circle
        CGContextSetLineWidth(context, 5.0)
        CGContextSetStrokeColorWithColor(context, UIColor.greenColor().CGColor)
        
        CGContextAddEllipseInRect(context, CGRect(x: 50, y: 200, width: 200, height: 200))
        CGContextStrokePath(context)
        
        imgView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    @IBAction func btnDrawArc(sender: UIButton) {
        UIGraphicsBeginImageContext(imgView.frame.size)
        let context = UIGraphicsGetCurrentContext()
        
        // Draw Arc
        CGContextSetLineWidth(context, 5.0)
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        
        CGContextMoveToPoint(context, 50, 50)
        CGContextAddArcToPoint(context, 200, 50, 200, 200, 50)
        CGContextAddLineToPoint(context, 200, 200)
        
        CGContextMoveToPoint(context, 100, 250)
        CGContextAddArcToPoint(context, 250, 250, 100, 400, 20)
        CGContextAddLineToPoint(context, 100, 400)
        
        CGContextStrokePath(context)
        
        imgView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    @IBAction func btnDrawFill(sender: UIButton) {
        UIGraphicsBeginImageContext(imgView.frame.size)
        let context = UIGraphicsGetCurrentContext()
        
        // Draw Rectangle
        CGContextSetLineWidth(context, 1.0)
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        CGContextSetFillColorWithColor(context, UIColor.redColor().CGColor)

        let rectangel = CGRect(x: 50, y: 50, width: 200, height: 100)
        CGContextAddRect(context, rectangel)
        CGContextFillRect(context, rectangel)
        CGContextStrokePath(context)

        // Draw Circle
        CGContextSetLineWidth(context, 1.0)
        CGContextSetStrokeColorWithColor(context, UIColor.blueColor().CGColor)
        CGContextSetFillColorWithColor(context, UIColor.blueColor().CGColor)

        let circle = CGRect(x: 50, y: 200, width: 200, height: 100)
        CGContextAddEllipseInRect(context, circle)
        CGContextFillEllipseInRect(context, circle)
        CGContextStrokePath(context)

        // Draw Triangle
        CGContextSetLineWidth(context, 1.0)
        CGContextSetStrokeColorWithColor(context, UIColor.greenColor().CGColor)
        CGContextSetFillColorWithColor(context, UIColor.greenColor().CGColor)

        CGContextMoveToPoint(context, 150, 350)
        CGContextAddLineToPoint(context, 250, 450)
        CGContextAddLineToPoint(context, 50, 450)
        CGContextAddLineToPoint(context, 150, 350)
        CGContextFillPath(context)
        CGContextStrokePath(context)
        
        imgView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
}

