//
//  ViewController.swift
//  DrawGraphics
//
//  Created by Ho-Jeong Song on 2015. 10. 6..
//  Copyright © 2015년 Ho-Jeong Song. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imgView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        drawFlower()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func drawFlower() {
        UIGraphicsBeginImageContext(imgView.frame.size)
        let context = UIGraphicsGetCurrentContext()
        
        // Draw Triangle
        CGContextSetLineWidth(context, 3.0)
        CGContextSetStrokeColorWithColor(context, UIColor.greenColor().CGColor)
        CGContextSetFillColorWithColor(context, UIColor.greenColor().CGColor)

        CGContextMoveToPoint(context, 140, 200)
        CGContextAddLineToPoint(context, 170, 450)
        CGContextAddLineToPoint(context, 110, 450)
        CGContextAddLineToPoint(context, 140, 200)
        CGContextFillPath(context)
        CGContextStrokePath(context)
        
        // Draw Circle
        CGContextSetLineWidth(context, 2.0)
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        
        CGContextAddEllipseInRect(context, CGRect(x: 90, y: 150, width: 100, height: 100))
        CGContextAddEllipseInRect(context, CGRect(x: 90+50, y: 150, width: 100, height: 100))
        CGContextAddEllipseInRect(context, CGRect(x: 90-50, y: 150, width: 100, height: 100))
        CGContextAddEllipseInRect(context, CGRect(x: 90, y: 150-50, width: 100, height: 100))
        CGContextAddEllipseInRect(context, CGRect(x: 90, y: 150+50, width: 100, height: 100))
        CGContextStrokePath(context)
        
        imgView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
}

