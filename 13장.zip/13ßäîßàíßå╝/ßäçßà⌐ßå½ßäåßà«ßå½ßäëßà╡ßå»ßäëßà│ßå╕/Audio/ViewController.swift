//
//  ViewController.swift
//  Audio
//
//  Created by LeeBeomGeun on 2016.
//  Copyright © 2016년 LeeBeomGeun. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate, AVAudioRecorderDelegate {
    
    var audioPlayer : AVAudioPlayer!
    var audioFile : NSURL!
    
    let MAX_VOLUME : Float = 10.0
    
    var progressTimer : NSTimer!
    let timePlayerSelector:Selector = #selector(ViewController.updatePlayTime)
    let timeRecordSelector:Selector = #selector(ViewController.updateRecordTime)
    
    @IBOutlet weak var pvProgressPlay: UIProgressView!
    @IBOutlet weak var lblCurrentTime: UILabel!
    @IBOutlet weak var lblEndTime: UILabel!
    @IBOutlet weak var btnPlay: UIButton!
    @IBOutlet weak var btnPause: UIButton!
    @IBOutlet weak var btnStop: UIButton!
    @IBOutlet weak var slVolumn: UISlider!
    
    @IBOutlet weak var btnRecord: UIButton!
    @IBOutlet weak var lblRecordTime: UILabel!
    var audioRecorder : AVAudioRecorder!
    var isRecordMode = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        selectAudioFile()
        if !isRecordMode {
            initPlay()
            btnRecord.enabled = false
            lblRecordTime.enabled = false
        } else {
            initRecord()
        }
        
    }
    
    func selectAudioFile() {
        if !isRecordMode {
            audioFile = NSBundle.mainBundle().URLForResource("Sicilian_Breeze", withExtension: "mp3")
        } else {
            let documentDirectory = NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)[0]
            audioFile = documentDirectory.URLByAppendingPathComponent("recordFile.m4a")
        }
    }
    
    func initRecord() {
        let recordSettings = [
            AVFormatIDKey : NSNumber(unsignedInt: kAudioFormatAppleLossless),
            AVEncoderAudioQualityKey : AVAudioQuality.Max.rawValue,
            AVEncoderBitRateKey : 320000,
            AVNumberOfChannelsKey : 2,
            AVSampleRateKey : 44100.0]
        do {
            audioRecorder = try AVAudioRecorder(URL: audioFile, settings: recordSettings)
        } catch let error as NSError {
            print("Error-initRecord : \(error)")
        }
        
        audioRecorder.delegate = self
        audioRecorder.meteringEnabled = true
        audioRecorder.prepareToRecord()

        slVolumn.value = 1.0
        audioPlayer.volume = slVolumn.value
        lblEndTime.text = convertNSTimeInerval2String(0)
        lblCurrentTime.text = convertNSTimeInerval2String(0)
        setPlayButtons(false, pause: false, stop: false)
        
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(AVAudioSessionCategoryPlayAndRecord)
        } catch let error as NSError {
            print(" Error-setCategory : \(error)")
        }
        do {
            try session.setActive(true)
        } catch let error as NSError {
            print(" Error-setActive : \(error)")
        }
    }
    
    func initPlay() {
        do {
            audioPlayer = try AVAudioPlayer(contentsOfURL: audioFile)
        } catch let error as NSError {
            print("Error-initPlay : \(error)")
        }
        slVolumn.maximumValue = MAX_VOLUME
        slVolumn.value = 1.0
        pvProgressPlay.progress = 0

        audioPlayer.delegate = self
        audioPlayer.prepareToPlay()
        audioPlayer.volume = slVolumn.value
        
        lblEndTime.text = convertNSTimeInerval2String(audioPlayer.duration)
        lblCurrentTime.text = convertNSTimeInerval2String(0)
        setPlayButtons(true, pause: false, stop: false)
    }
    
    func setPlayButtons(play:Bool, pause:Bool, stop:Bool) {
        btnPlay.enabled = play
        btnPause.enabled = pause
        btnStop.enabled = stop
    }
    
    func convertNSTimeInerval2String(time:NSTimeInterval) -> String {
        let min = Int(time/60)
        let sec = Int(time%60)
        let strTime = String(format: "%02d:%02d", min, sec)
        return strTime
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func btnPlayAudio(sender: UIButton) {
        audioPlayer.play()
        setPlayButtons(false, pause: true, stop: true)
        progressTimer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: timePlayerSelector, userInfo: nil, repeats: true)
    }
    
    func updatePlayTime() {
        lblCurrentTime.text = convertNSTimeInerval2String(audioPlayer.currentTime)
        pvProgressPlay.progress = Float(audioPlayer.currentTime/audioPlayer.duration)
    }
    
    @IBAction func btnPauseAudio(sender: UIButton) {
        audioPlayer.pause()
        setPlayButtons(true, pause: false, stop: true)
    }

    @IBAction func btnStopAudio(sender: UIButton) {
        audioPlayer.stop()
        audioPlayer.currentTime = 0
        lblCurrentTime.text = convertNSTimeInerval2String(0)
        setPlayButtons(true, pause: false, stop: false)
        progressTimer.invalidate()
        
    }

    @IBAction func slChangeVolumn(sender: UISlider) {
        audioPlayer.volume = slVolumn.value
    }
    
    func audioPlayerDidFinishPlaying(player: AVAudioPlayer, successfully flag: Bool) {
        progressTimer.invalidate()
        setPlayButtons(true, pause: false, stop: false)
    }

    
    @IBAction func swRecordMode(sender: UISwitch) {
        if sender.on {
            isRecordMode = true
            btnRecord.enabled = true
            lblRecordTime.enabled = true
        } else {
            isRecordMode = false
            btnRecord.enabled = false
            lblRecordTime.enabled = false
            lblRecordTime.text = convertNSTimeInerval2String(0)
        }
        selectAudioFile()
        if !isRecordMode {
            initPlay()
        } else {
            initRecord()
        }
    }
    
    @IBAction func btnRecord(sender: UIButton) {
        if sender.titleLabel?.text == "Record" {
            audioRecorder.record()
            sender.setTitle("Stop", forState: .Normal)
            progressTimer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: timeRecordSelector, userInfo: nil, repeats: true)
        } else {
            audioRecorder.stop()
            progressTimer.invalidate()
            sender.setTitle("Record", forState: .Normal)
            btnPlay.enabled = true
            initPlay()
        }
    }
    
    func updateRecordTime() {
        lblRecordTime.text = convertNSTimeInerval2String(audioRecorder.currentTime)
    }
    
}










