//
//  ViewController.swift
//  WebView
//
//  Created by bglee
//  Copyright © 2015년 bglee. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIWebViewDelegate {

    @IBOutlet weak var myWebViewView: UIWebView!
    @IBOutlet weak var myActivityIndicator: UIActivityIndicatorView!
    
    func loadWebViewPage(url: String) {
        let myUrl = NSURL(string: url)
        let myRequest = NSURLRequest(URL: myUrl!)
        myWebViewView.loadRequest(myRequest)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let myHtmlBundle = NSBundle.mainBundle()
        let filePath = myHtmlBundle.pathForResource("htmlView", ofType: "html")
        loadWebViewPage(filePath!)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func webViewDidStartLoad(webView: UIWebView) {
        myActivityIndicator.startAnimating()
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        myActivityIndicator.stopAnimating()
    }
}

