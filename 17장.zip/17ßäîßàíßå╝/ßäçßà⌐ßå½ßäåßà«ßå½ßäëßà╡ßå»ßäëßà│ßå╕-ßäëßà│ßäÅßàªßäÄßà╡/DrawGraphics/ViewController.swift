//
//  ViewController.swift
//  DrawGraphics
//
//  Created by Ho-Jeong Song on 2015. 10. 5..
//  Copyright © 2015년 Ho-Jeong Song. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imgView: UIImageView!
    
    var lastPoint: CGPoint!
    var lineSize:CGFloat = 2.0
    var lineColor = UIColor.redColor().CGColor
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func clearImageView(sender: UIButton) {
        imgView.image = nil
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        let touch = touches.first!
        
        lastPoint = touch.locationInView(imgView)
    }
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        UIGraphicsBeginImageContext(imgView.frame.size)
        CGContextSetStrokeColorWithColor(UIGraphicsGetCurrentContext(), lineColor)
        CGContextSetLineCap(UIGraphicsGetCurrentContext(),CGLineCap.Round)
        CGContextSetLineWidth(UIGraphicsGetCurrentContext(), lineSize)
        
        let touch = touches.first! as UITouch
        let currPoint = touch.locationInView(imgView)
        
        imgView.image?.drawInRect(CGRectMake(0, 0, imgView.frame.size.width, imgView.frame.size.height))
        
        CGContextMoveToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y)
        CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), currPoint.x, currPoint.y)
        CGContextStrokePath(UIGraphicsGetCurrentContext())
        
        imgView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        lastPoint = currPoint
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        UIGraphicsBeginImageContext(imgView.frame.size)
        CGContextSetStrokeColorWithColor(UIGraphicsGetCurrentContext(), lineColor)
        CGContextSetLineCap(UIGraphicsGetCurrentContext(),CGLineCap.Round)
        CGContextSetLineWidth(UIGraphicsGetCurrentContext(), lineSize)
        
        imgView.image?.drawInRect(CGRectMake(0, 0, imgView.frame.size.width, imgView.frame.size.height))
        
        CGContextMoveToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y)
        CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y)
        CGContextStrokePath(UIGraphicsGetCurrentContext())
        
        imgView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    override func motionEnded(motion: UIEventSubtype, withEvent event: UIEvent?) {
        if motion == .MotionShake {
            imgView.image = nil
        }
    }
    
}
